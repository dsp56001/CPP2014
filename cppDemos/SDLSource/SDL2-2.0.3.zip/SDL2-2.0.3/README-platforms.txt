
This is a list of the platforms SDL supports, and who maintains them.

Officially supported platforms
==============================
(code compiles, and thoroughly tested for release)
==============================
Windows XP/Vista/7/8
Mac OS X 10.5+
Linux 2.6+
iOS 5.1.1+
Android 2.3.3+

Unofficially supported platforms
================================
(code compiles, but not thoroughly tested)
================================
FreeBSD
NetBSD
OpenBSD
Solaris

Platforms supported by volunteers
=================================
Haiku - maintained by Axel Dörfler <axeld@pinc-software.de>
PSP - maintained by 527721088@qq.com
Pandora - maintained by Scott Smith <pickle136@sbcglobal.net>

Platforms that need maintainers
===============================
